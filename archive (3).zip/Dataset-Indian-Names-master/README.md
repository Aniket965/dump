# Dataset_Indian_Names
The repository contains code for creating dataset for Indian names by preprocessing with some available datasets on google .
